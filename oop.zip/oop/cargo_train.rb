class CargoTrain < Train

  def initialize(number)
    super(number)
    @type = 'Cargo Train'
  end
  attr_reader :type

  def add_carriage(cargo_carriage)
    cargo_carriage.new_carriage(self)
  end

end


