# frozen_string_literal: true

require_relative 'cargo_carriage.rb'
require_relative 'cargo_train.rb'
require_relative 'passenger_carriage.rb'
require_relative 'passenger_train'
require_relative 'route.rb'
require_relative 'station.rb'
require_relative 'train.rb'
require_relative 'seed.rb'

class Main
  user_input = nil
  puts 'Привет, это программа-абстракция железной дороги'
  while user_input != 0
    puts 'Введите 1, если вы хотите создать станцию'
    puts 'Введите 2, если вы хотите создать поезд'
    puts 'Введите 3, если вы хотите создать маршрут и управлять станциями в нем (добавлять, удалять)'
    puts 'Введите 4, если вы хотите назначить маршрут поезду'
    puts 'Введите 5, если вы хотите добавлять вагоны к поезду'
    puts 'Введите 6, если вы хотите отцеплять вагоны от поезда'
    puts 'Введите 7, если вы хотите перемещать поезд по маршруту вперед и назад'
    puts 'Введите 8, если вы хотите просматривать список станций и список поездов на станции'
    puts 'Введите 0, если хотите закончить программу'

    user_input = gets.to_i
    if user_input == 1
      puts 'Введите название станции'
      station_name = gets.chomp
      station = Station.new(station_name)
      puts "Станция \"#{station.name} \" создана"
    elsif user_input == 2
      puts 'Введите номер поезда'
      train_number = gets.chomp
      puts 'Введите тип поезда'
      train_type = gets.chomp
      puts 'Введите количество вагонов'
      train_carriage = gets.to_i
      train = Train.new(train_number, train_type, train_carriage)
      puts "Поезд под номером \"#{train.number} \"  создан успешно. Тип поезда \"#{train.type} \". Количество вагонов поезда: #{train.number_of_cars} "
    elsif user_input == 3
      puts 'Введите начальную станцию'
      station = Station.new(gets.chomp)
      initial_station = station
      puts 'Введите конечную станцию'
      station = Station.new(gets.chomp)
      end_station = station
      route = Route.new(initial_station, end_station)
      puts "Путь со станциями #{route.station_list}  создан успешно."
      remove = nil
      while remove != 0
        puts 'Хотите добавить станцию - нажмите 1; удалить станцию - нажмите 2; закончить процесс добавления - нажмите 0'

        remove = gets.to_i
        case remove

        when 1
          puts 'Введите наименование станции, которую хотите добавить'
          station = Station.new(gets.chomp)
          intermediate_station = station
          route.add_intermediate_station(intermediate_station)
          puts "Путь со станциями #{route.station_list}  изменен успешно."
        when 2
          puts 'Введите наименование станции, которую хотите удалить'
          station = Station.new(gets.chomp)
          intermediate_station = station
          if route.station_list[1..-2].include?(intermediate_station)
            route.delete_intermediate_station(intermediate_station)
            puts "Путь со станциями #{route.station_list}  изменен успешно."
          else
            puts 'Нет такой станции в составе пути'
         end
        when 0
          break
           end
      end
    elsif user_input == 4
      train.add_route(route)
      puts "Путь поезду назначен: текущая станция #{train.current_station.name}"
    elsif  user_input == 5
      train.add_carriage
      puts "Количество вагонов составляет #{train.number_of_cars} единиц"
    elsif  user_input == 6
      train.remove_carriage
      puts "Количество вагонов составляет #{train.number_of_cars} единиц"
    elsif  user_input == 7
      remove = nil
      while remove != 0
        puts 'Если хотите перемещать поезд по маршруту вперед - нажмите 1; назад - нажмите 2; закончить процесс - нажмите 0'
        remove = gets.to_i
        case remove
        when 1
          train.go_forward
          puts "текущая станция #{train.current_station.name}"
        when 2
          train.transit_station_back
          puts "текущая станция #{train.current_station.name}"
        end
        end
    elsif  user_input == 8
      remove = nil
      while remove != 0
        puts 'Если хотите просмотреть список станций - нажмите 1; список поездов на станции - нажмите 2; закончить процесс - нажмите 0'
        remove = gets.to_i
        case remove
        when 1
          puts "Список станций #{route.show_station_list}"
        when 2
          puts "Список поездов на станции #{train.current_station.show_trains}"
        end
      end
    elsif  user_input == 0
      puts 'Программа завершена'
    else
      'Введите значение из списка'
    end
    puts 'ok'
    end
end
