# frozen_string_literal: true

class PassengerCarriage
  attr_accessor :passenger_train_carriages
  def initialize
    @passenger_train_carriages = []
  end

end
