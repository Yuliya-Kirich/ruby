# frozen_string_literal: true

class PassengerTrain < Train
 # attr_reader :a
  def initialize(number)
    super(number)
    @number_of_passenger_cars=[]
  end
  attr_reader :type

  def add_carriage(*passenger_carriage)
    sum = passenger_carriage.collect { |i| a << i.carriage } if @speed.zero?
    puts sum
  end

  def add_carriages(passenger_carriage)
    passenger_carriage.passenger_train_carriages << passenger_carriage.itself
  end

  def remove_carriage(passenger_carriage)
    passenger_carriage.passenger_train_carriages -= [passenger_carriage.itself]
    end
end
