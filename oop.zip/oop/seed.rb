class Seed
end