# frozen_string_literal: true

class CargoCarriage
  def new_carriage
    self
  end
end
